GATEWAY ARCH — FINAL PROJECT SUBMISSION

Main deliverable: Gateway_Arch_Interactive_Presentation.html
Supporting planning file: Gateway_Arch_Completed_Spreadsheet.xlsx
Assignment reference: Assignment_Requirements.pdf

HOW TO OPEN
1. Extract this ZIP to a folder.
2. Double-click Gateway_Arch_Interactive_Presentation.html in Chrome or Edge.
3. Use the chapter navigation or click the map markers.
4. Keep internet access enabled for the detailed map background and any remotely loaded photographs.

NOTES
This package preserves the previously approved presentation, including the original uploaded photographs and added church photograph. Some archival photo identifications have not been verified; some map points are approximate. Check the assignment rubric and test the presentation in your browser before submitting.
